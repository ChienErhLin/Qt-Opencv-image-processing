# Qt-Opencv-image-processing
simple image processing using qt and opencv
